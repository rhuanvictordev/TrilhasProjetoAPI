import { Routes } from '@angular/router';
import { Trilhas } from './pages/trilhas/trilhas';

export const routes: Routes = [
  {
    path: 'trilhas',
    component: Trilhas
  }
];